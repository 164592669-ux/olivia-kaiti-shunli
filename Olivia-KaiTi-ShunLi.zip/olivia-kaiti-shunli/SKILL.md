---
name: olivia-kaiti-shunli
description: 给播音与主持艺术专业学生用的开题报告（设计／作品创作类）自查与改写助手，按写作要求逐栏指出问题，在 Word 原生批注里给出可直接替换的整段改写示范。This skill should be used when a student uploads a thesis proposal / 开题报告 .docx and asks to check, revise, improve, or get rewrite suggestions for it, especially for broadcasting and announcing (播音与主持艺术) majors.
agent_created: true
---

# Olivia-KaiTi-ShunLi

## 用途

帮助学生自己修改开题报告（课题类型＝设计／作品创作）：按写作要求逐栏检查，用 Word 的插入批注功能在原稿对应句子上写出**问题 + 可直接替换的整段改写示范**。语气温和，像助教在旁边提示；不改正文、不打分、不批评。

不适用于论文类开题报告。PDF 需先转成 .docx，扫描件需先 OCR。

## 工作流

### 1. 读取与机械核查

执行 `python scripts/proposal_tool.py check <原稿.docx> -o report.json`，读取：

- `paragraphs`：带 `index` 的段落清单，批注锚点用它定位
- `sections`：三栏字数是否达标
- `references`：条目数、近五年篇数、年份、排序情况
- `keywords`：文献综述关键词
- `first_person_hits`：正文里的人称线索

### 2. 按写作要求逐栏判断

读取 `references/writing-rules.md` 逐栏核对；读取 `references/sample-structure.md` 作为合格结构参照。

- 对照第 6 节「这些不用纠结」，命中任一条即不生成批注。
- 加分项缺失不记问题；弹性项只作提醒。
- 两个**必需项**务必核对，漏掉即算漏查：
  - 目的段首句之后，是否写清作品形式、有声语言分工（主持／访谈／配音各自目的）、达到什么效果、让观众感受到什么
  - 文献综述末尾是否有**综合小结**（收拢文献对自己作品的启发）

### 3. 联网核验参考文献

执行 `python scripts/proposal_tool.py refs <原稿.docx>`，按「题名 + 作者」逐条检索是否真实存在。查不到只标「待核验」并温和提醒学生自己上知网核对，**不得判定为编造**。客户端无联网能力时生成一条「未联网核验」提醒。

### 4. 写学生版批注

读取 `references/revision-phrases.md`，按触发情形取用并改写成贴合原文的话：

- **温和指导、不批评**：说清「哪里没写到」「为什么要这样写」「可以怎么改」，像助教提示；不用质问、不拿参考范文压人、不说重话、不打分
- **每处给整段可替换示范**：把改好的**一整段**写进批注（用『……』包起来），学生可以直接复制替换，不只是给一两句提示
- 示范段里的人名、片名、场景用 `{……}` 占位，并在每条批注末尾提醒「按你自己的片子换掉具体的人、场景和作品名，别整段照抄」
- 示范段是**要抄进正文的**，一律用「笔者／创作者」，不得出现「我／我们」
- 批注正文里可以用「你」「我们」，但不用批评语气
- **多处体现**：文中每一处有问题的句子都批到，各挂各的锚点；不同位置不攒成一条，同一段的不同问题分开写
- 不出现规则编号、检查项名称、评分、等级，也不得以 AI／系统身份自述
- 不生成「退回重写」「不同意开题」这类结论

### 5. 汇总批注清单

按 `assets/comments.example.json` 生成 `comments.json`，每条含 `paragraph`、`anchor_text`（从该段原文复制的短句）、`text`（批注正文，可含多行整段示范）。

不同位置的问题分别写条目、各挂各的锚点，不要为精简而合并。

### 6. 写回批注版文档

执行 `python scripts/proposal_tool.py apply <原稿.docx> comments.json -o <原名>_修改指导版.docx --author "改稿助手" --initials "助"`。

- 生成 Word / WPS 右侧可逐条答复、解决的原生批注气泡；不改正文
- 输出为新文件，原稿不动
- 读取返回的 `unmatched` / `failed`，向用户报告降级与未写入情况

### 7. 汇报

告知批注条数、未定位锚点、待核验文献条目数、输出文件路径。不输出评分、等级或总体结论。

## 铁律

- 一律语气温和，**不批评、不质问、不拿参考范文压人**；不出现老师版那两句重话
- 不改正文、不生成正文已替换的稿子；只给批注
- 每条批注必须给**整段可替换示范**，不能只写「请修改」「建议补充」
- 示范段用「笔者／创作者」，标注需替换的专有名词，并提醒按自己作品改写，避免全班雷同
- 不打分、不评等级、不写行政结论
- 查不到文献 ≠ 编造，只标「待核验」
- 对照「这些不用纠结」逐条自查，命中即删掉该批注
- 不得暴露老师版的批改口径、批评话术或规则编号

## 双端与降级

- WorkBuddy 本地：完整流程可跑。
- 豆包工作：在「工作任务」选**本地电脑**运行，脚本读写文件需授权。
- 无脚本能力时只执行到步骤 5，产出 `comments.json`，拷回本地执行 `apply` 即可生成批注版。

## 资源

- `references/writing-rules.md` — 四栏写作要求、硬指标、不用纠结清单
- `references/revision-phrases.md` — 温和指导话术库（每条含整段可替换示范）
- `references/sample-structure.md` — 合格定稿的结构骨架
- `scripts/proposal_tool.py` — `check` / `refs` / `apply` 三个子命令
- `assets/comments.example.json` — 批注清单格式示例
- `README.md` — 安装、用法、依赖
